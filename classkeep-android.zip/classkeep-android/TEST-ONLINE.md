# Build and test without installing anything

1. Make a free account at github.com and create a new repository (any name).
2. Upload everything in this folder. If the hidden `.github` folder does not upload,
   in the repo click Add file > Create new file, type the name
   `.github/workflows/build.yml`, and paste in the contents of `build-apk.yml.txt`.
3. Open the repo's Actions tab. The "Build APK" run starts by itself (or click
   Run workflow). It takes about 5 to 10 minutes the first time.
4. When it turns green, open the run and download `classkeep-debug-apk` at the bottom.
   Unzip it to get the .apk.
5. Test it:
   - On an Android phone: copy the .apk over, tap it, and allow install from this source.
   - In a browser: upload the .apk to appetize.io (check its current free limits).

If the run fails (red), open it, click the failed step, and copy the error text.
