package com.example.classkeep

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

private const val SCHEMA_VERSION = 1 // keep equal to @Database(version)

suspend fun exportDb(ctx: Context, to: Uri): Boolean = withContext(Dispatchers.IO) {
    try {
        // Fold the write-ahead log into the main file so the copy is complete.
        Db.get(ctx).openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        val file = ctx.getDatabasePath(DB_NAME)
        val out = ctx.contentResolver.openOutputStream(to) ?: return@withContext false
        out.use { o -> file.inputStream().use { it.copyTo(o) } }
        true
    } catch (e: Exception) { false }
}

/** Validates the file first, keeps a .bak of the current data, then swaps it in. Caller restarts the app. */
suspend fun restoreDb(ctx: Context, from: Uri): Boolean = withContext(Dispatchers.IO) {
    val tmp = File(ctx.cacheDir, "restore.db")
    try {
        val input = ctx.contentResolver.openInputStream(from) ?: return@withContext false
        input.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        val version = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READONLY).use { it.version }
        if (version != SCHEMA_VERSION) { tmp.delete(); return@withContext false }
        val dbFile = ctx.getDatabasePath(DB_NAME)
        Db.close()
        if (dbFile.exists()) dbFile.copyTo(File(dbFile.path + ".bak"), overwrite = true)
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
        tmp.copyTo(dbFile, overwrite = true)
        tmp.delete()
        true
    } catch (e: Exception) { tmp.delete(); false }
}

fun restartApp(ctx: Context) {
    val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return
    ctx.startActivity(Intent.makeRestartActivityTask(launch.component))
    Runtime.getRuntime().exit(0)
}

@Composable
fun BackupScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Uri?>(null) }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch { msg = if (exportDb(ctx, uri)) "Backup saved." else "Backup failed." }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> pending = uri }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Backup and restore", style = MaterialTheme.typography.titleMedium)
        Text("Save a copy of all your data to Drive, a file manager, or another phone. Restore it on a new device.")
        Button(onClick = { export.launch("backup-${LocalDate.now()}.db") }) { Text("Save backup") }
        OutlinedButton(onClick = { restore.launch(arrayOf("*/*")) }) { Text("Restore from backup") }
        if (msg.isNotEmpty()) Text(msg)
    }
    pending?.let { uri ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Replace all data?") },
            text = { Text("Restoring replaces everything on this phone with the backup. The app will restart.") },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    scope.launch { if (restoreDb(ctx, uri)) restartApp(ctx) else msg = "That file is not a valid backup for this app version." }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }
}
