package com.example.classkeep

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.temporal.ChronoUnit

// Money is stored as integer minor units (cents/paise). Dates are ISO yyyy-MM-dd text.
@Entity
data class Batch(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(
    foreignKeys = [ForeignKey(entity = Batch::class, parentColumns = ["id"], childColumns = ["batchId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("batchId")]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val batchId: Long, val name: String, val rollNo: Int,
    val phone: String, val monthlyFee: Long, val joinedOn: String
)

@Entity(
    primaryKeys = ["studentId", "date"],
    foreignKeys = [ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.CASCADE)]
)
data class Attendance(val studentId: Long, val date: String, val present: Boolean)

@Entity(
    foreignKeys = [ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("studentId")]
)
data class Payment(@PrimaryKey(autoGenerate = true) val id: Long = 0, val studentId: Long, val amount: Long, val paidOn: String)

@Dao
interface ClassDao {
    @Insert suspend fun addBatch(b: Batch): Long
    @Query("SELECT * FROM Batch ORDER BY name") fun batches(): Flow<List<Batch>>
    @Insert suspend fun addStudent(s: Student)
    @Query("SELECT * FROM Student ORDER BY batchId, rollNo") fun students(): Flow<List<Student>>
    @Upsert suspend fun mark(a: Attendance)
    @Query("DELETE FROM Attendance WHERE date = :d AND studentId IN (SELECT id FROM Student WHERE batchId = :b)")
    suspend fun resetDay(d: String, b: Long)
    @Query("SELECT * FROM Attendance WHERE date = :d") fun attendanceOn(d: String): Flow<List<Attendance>>
    @Insert suspend fun pay(p: Payment): Long
    @Query("SELECT COALESCE(SUM(amount), 0) FROM Payment WHERE studentId = :id") suspend fun paidTotal(id: Long): Long
    @Query("SELECT * FROM Payment") fun payments(): Flow<List<Payment>>
}

const val DB_NAME = "classkeep.db"

@Database(entities = [Batch::class, Student::class, Attendance::class, Payment::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): ClassDao
    companion object {
        @Volatile private var inst: Db? = null
        fun close() = synchronized(this) { inst?.close(); inst = null }
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, DB_NAME).build().also { inst = it }
        }
    }
}

/** Dues = every month since joining (this month included) times the monthly fee, minus payments. */
fun dueFor(s: Student, paid: Long, today: LocalDate = LocalDate.now()): Long {
    val start = LocalDate.parse(s.joinedOn).withDayOfMonth(1)
    val months = ChronoUnit.MONTHS.between(start, today.withDayOfMonth(1)) + 1
    return maxOf(0L, months * s.monthlyFee - paid)
}

fun money(minor: Long) = "%.2f".format(minor / 100.0)
