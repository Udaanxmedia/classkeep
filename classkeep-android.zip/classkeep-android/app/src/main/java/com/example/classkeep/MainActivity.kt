package com.example.classkeep

import android.app.Application
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class Vm(app: Application) : AndroidViewModel(app) {
    private val dao = Db.get(app).dao()
    private fun <T> kotlinx.coroutines.flow.Flow<List<T>>.hot() = stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val today: String = LocalDate.now().toString()
    val batches = dao.batches().hot()
    val students = dao.students().hot()
    val payments = dao.payments().hot()
    val attendance = dao.attendanceOn(today).hot()

    fun addBatch(name: String) = viewModelScope.launch { dao.addBatch(Batch(name = name.trim())) }
    fun addStudent(batchId: Long, name: String, roll: String, phone: String, fee: String) = viewModelScope.launch {
        dao.addStudent(Student(batchId = batchId, name = name.trim(), rollNo = roll.toIntOrNull() ?: 0, phone = phone.trim(),
            monthlyFee = toMinor(fee), joinedOn = today))
    }
    fun mark(studentId: Long, present: Boolean) = viewModelScope.launch { dao.mark(Attendance(studentId, today, present)) }
    fun resetToday(batchId: Long) = viewModelScope.launch { dao.resetDay(today, batchId) }
    val receipt = MutableStateFlow<String?>(null)
    fun pay(studentId: Long, amount: String) = viewModelScope.launch {
        val m = toMinor(amount)
        val s = students.value.firstOrNull { it.id == studentId }
        if (m <= 0 || s == null) return@launch
        val id = dao.pay(Payment(studentId = studentId, amount = m, paidOn = today))
        val due = dueFor(s, dao.paidTotal(studentId))
        receipt.value = "Fee receipt #$id\nDate: $today\nStudent: ${s.name} (Roll ${s.rollNo})\n" +
            "Amount received: ${money(m)}\nBalance due: ${money(due)}"
    }
    private fun toMinor(s: String) = Math.round((s.toDoubleOrNull() ?: 0.0) * 100)
}

class MainActivity : ComponentActivity() {
    private val vm: Vm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App(vm) } } }
    }
}

@Composable
fun App(vm: Vm) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Students" to Icons.Filled.Person, "Attendance" to Icons.Filled.Check, "Fees" to Icons.Filled.AccountBox, "Backup" to Icons.Filled.Settings)
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (label, icon) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, label) }, label = { Text(label) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).statusBarsPadding()) {
            when (tab) { 0 -> StudentsScreen(vm); 1 -> AttendanceScreen(vm); 2 -> FeesScreen(vm); else -> BackupScreen() }
        }
    }
}

@Composable
fun StudentsScreen(vm: Vm) {
    val batches by vm.batches.collectAsState()
    val students by vm.students.collectAsState()
    var dlg by remember { mutableIntStateOf(0) }
    Column(Modifier.padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { dlg = 1 }) { Text("Add batch") }
            Button(onClick = { dlg = 2 }, enabled = batches.isNotEmpty()) { Text("Add student") }
        }
        if (students.isEmpty()) Text("No students yet. Add a batch, then a student.", Modifier.padding(top = 24.dp))
        LazyColumn {
            items(students, key = { it.id }) { s ->
                ListItem(
                    headlineContent = { Text("${s.rollNo}. ${s.name}") },
                    supportingContent = { Text(batches.firstOrNull { it.id == s.batchId }?.name ?: "") }
                )
            }
        }
    }
    if (dlg == 1) FormDialog("New batch", listOf("Name"), { dlg = 0 }) { vm.addBatch(it[0]) }
    if (dlg == 2) {
        var batchId by remember { mutableLongStateOf(batches.first().id) }
        FormDialog("New student", listOf("Name", "Roll no.", "Phone", "Monthly fee"), { dlg = 0 },
            extra = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    batches.forEach { b -> FilterChip(selected = b.id == batchId, onClick = { batchId = b.id }, label = { Text(b.name) }) }
                }
            }) { vm.addStudent(batchId, it[0], it[1], it[2], it[3]) }
    }
}

@Composable
fun AttendanceScreen(vm: Vm) {
    val batches by vm.batches.collectAsState()
    val students by vm.students.collectAsState()
    val marks by vm.attendance.collectAsState()
    var batchId by remember { mutableLongStateOf(-1L) }
    val selected = if (batchId == -1L) batches.firstOrNull()?.id else batchId
    Column(Modifier.padding(16.dp)) {
        Text("Attendance for ${vm.today}", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            batches.forEach { b -> FilterChip(selected = b.id == selected, onClick = { batchId = b.id }, label = { Text(b.name) }) }
        }
        if (selected != null) OutlinedButton(onClick = { vm.resetToday(selected) }) { Text("Reset today") }
        LazyColumn {
            items(students.filter { it.batchId == selected }, key = { it.id }) { s ->
                val state = marks.firstOrNull { it.studentId == s.id }?.present
                ListItem(
                    headlineContent = { Text("${s.rollNo}. ${s.name}") },
                    trailingContent = {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = state == true, onClick = { vm.mark(s.id, true) }, label = { Text("P") })
                            FilterChip(selected = state == false, onClick = { vm.mark(s.id, false) }, label = { Text("A") })
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun FeesScreen(vm: Vm) {
    val students by vm.students.collectAsState()
    val payments by vm.payments.collectAsState()
    var payFor by remember { mutableStateOf<Student?>(null) }
    val receipt by vm.receipt.collectAsState()
    Column(Modifier.padding(16.dp)) {
        Text("Fees", style = MaterialTheme.typography.titleMedium)
        LazyColumn {
            items(students, key = { it.id }) { s ->
                val due = dueFor(s, payments.filter { it.studentId == s.id }.sumOf { it.amount })
                ListItem(
                    headlineContent = { Text(s.name) },
                    supportingContent = { Text(if (due > 0) "Due ${money(due)}" else "Paid up") },
                    trailingContent = { TextButton(onClick = { payFor = s }) { Text("Record payment") } }
                )
            }
        }
    }
    payFor?.let { s -> FormDialog("Payment from ${s.name}", listOf("Amount"), { payFor = null }) { vm.pay(s.id, it[0]) } }
    receipt?.let { ReceiptDialog(it) { vm.receipt.value = null } }
}

@Composable
fun FormDialog(title: String, labels: List<String>, onClose: () -> Unit, extra: @Composable (() -> Unit)? = null, onDone: (List<String>) -> Unit) {
    val values = remember { mutableStateListOf(*Array(labels.size) { "" }) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                extra?.invoke()
                labels.forEachIndexed { i, l -> OutlinedTextField(values[i], { values[i] = it }, label = { Text(l) }, singleLine = true) }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(values.toList()); onClose() }, enabled = values[0].isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun ReceiptDialog(text: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Receipt") },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                ctx.startActivity(Intent.createChooser(send, "Share receipt"))
            }) { Text("Share") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}
