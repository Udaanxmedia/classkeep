# Architecture: ClassKeep (Android, working name)

Stack: Kotlin, Jetpack Compose (Material 3), Room (SQLite). No backend, no account. Offline by design.

- **Why local-only:** the original's selling point is working without internet; a local database is the most reliable way to ship that, and it removes the crash-prone sync and login paths reviewers complain about.
- **Money:** integer minor units. **Dates:** ISO text, local time.
- **Schema:** the Room entities in `Data.kt` (Batch, Student, Attendance, Payment). Attendance has a composite key so one mark per student per day. Foreign keys cascade on delete.
- **Dues rule:** months since joining times monthly fee, minus payments (`dueFor`).

## Build order
1. Vertical slice (done): batches, students, attendance, fees (S04-S09).
2. Done: receipts (share as text), backup and restore (file via the system picker, validated, with a .bak safety copy). Still open: SMS reminders (phone SMS app via intent), reports, exam marks, staff roles, student edit and delete.
3. Should/could after that.

## Riskiest parts
Backup/restore integrity, SMS sending rules, and staff permissions without a server (a device-level PIN per role is the offline option).
