# Recon map: Tufee (iPhone)

Scope: core loop (students, batches, attendance, fees, reports) with offline-first behavior. Exams and staff permissions as "should". Student portal, live classes, store out of scope for v1.
For: a product to sell to tutors and small coaching centers, rebranded.
Date: 2026-10-04

## Sources

| # | source | URL | notes |
| --- | --- | --- | --- |
| 1 | App Store listing, description, version history, reviews | https://apps.apple.com/in/app/tufee/id6740474461 | main source; 8 ratings, 4.0 |
| 2 | Search-index copy of the listing | https://mwm.ai/apps/tufee/6740474461 | released Jan 15 2025 |
| 3 | Student companion app listing | https://apps.apple.com/app/id6478205217 | results, attendance, fees view |
| 4 | Privacy policy | https://tufee.codedbypatel.com/policy/tufeeMultiUser | not yet read |
| 5 | The user's own account | not yet | needed for real screens and states |

Not yet used: help center (none found), pricing page (none found), walkthrough videos, screenshots.

## Core loop

A tutor adds students into batches, marks attendance in one tap, records fee payments, and sends SMS reminders to those with dues, all on a phone and without needing internet.

## Screens (inferred from feature descriptions; confirm with screenshots)

| ID | screen | route / how to reach | purpose | key components | states seen |
| --- | --- | --- | --- | --- | --- |
| S01 | Login / sign up | launch | admin account | email form | not seen |
| S02 | Institute setup | first run, settings | type, currency, language, feature toggles | toggles, pickers | not seen |
| S03 | Dashboard | home | summary of dues, attendance, earnings | cards | not seen |
| S04 | Students list | tab | browse, search, sort by name or roll no. | list, search | not seen |
| S05 | Add/edit student | from S04 | profile, photo, batch | form, image picker | not seen |
| S06 | Batches | tab | create batches, subjects | list, form | not seen |
| S07 | Attendance | per batch | one-tap present/absent, history, reset | toggle rows, date picker | not seen |
| S08 | Fees overview | tab | dues by student, filters | list, status chips | not seen |
| S09 | Add fee payment | from S08 | select due items, amount, receipt | form | not seen |
| S10 | Fee receipt | after S09 | digital receipt to share | document view | not seen |
| S11 | Send reminder | from S08 | SMS to student/parent | message composer | not seen |
| S12 | Exams | tab | create exam, enter marks, absent, series | list, grid entry | not seen |
| S13 | Report card | from S12 | per-student summary | document view | not seen |
| S14 | Reports | tab | fee status, profit/loss, attendance trends | charts | not seen |
| S15 | Staff and permissions | settings | staff list, salary, role access | list, permission toggles | not seen |
| S16 | Backup / restore | settings | export and restore data | buttons | not seen |

## Flows

```
F01 Tutor adds a student to a batch
    S04 -> S05 -> S06 (pick batch) -> back to S04
    edge: no batches yet, photo upload fails, duplicate roll number
F02 Mark today's attendance
    S06 or S07 -> pick batch -> tap present/absent -> save
    edge: marked by mistake (reset), offline, past date
F03 Record a fee payment
    S08 -> pick student -> S09 (due items preselected) -> S10 receipt
    edge: partial payment, late fee, custom currency, offline
F04 Remind everyone with dues
    S08 -> filter dues -> S11 -> send SMS
    edge: no phone number, SMS fails, app closes (a reviewer reports this)
F05 Enter exam marks
    S12 -> pick exam -> enter marks or mark absent -> S13 report card
F06 Back up and move to a new phone
    S16 -> export -> install on new device -> restore
```
Happy path clicks to measure on the original: F02 and F03.

## Components

| component | variants | states | used on |
| --- | --- | --- | --- |
| List row | student, fee, exam | default, selected | S04, S08, S12 |
| Toggle / present-absent chip | present, absent | default, selected | S07 |
| Form field | text, number, date, picker | default, error, disabled | S05, S09 |
| Image picker | avatar | empty, filled, error | S05 |
| Status chip | paid, due, overdue | | S08 |
| Chart | bar, line | empty, filled | S03, S14 |
| Permission toggle | per feature | on, off | S15 |

## Inferred data model

```
Institute   id, name, type (tuition|school|academy), currency, language, enabled_features
            evidence: v3.0 notes, v2.4.7 notes; confidence: medium
Staff       id, institute_id, name, role, permissions (json), salary
            evidence: review (permission-based access, salaries), 2.4.7; confidence: medium
Batch       id, institute_id, name, fee_plan
            evidence: description ("Student & Batch Management"); confidence: high
Student     id, batch_id, name, roll_no, phone, photo, birthday
            evidence: description, birthday reminders, ID cards; confidence: high
Attendance  id, student_id, date, status (present|absent), batch_id
            evidence: description, "Attendance Reset"; confidence: high
FeeItem     id, student_id, amount, due_date, late_fee_rule
            evidence: "due fee items auto-selected", late fees; confidence: medium
Payment     id, student_id, fee_item_ids, amount, paid_at, receipt_no
            evidence: description, receipts; confidence: high
Exam        id, batch_id, name, series_id, subject
            evidence: v3.0 notes; confidence: medium
ExamMark    id, exam_id, student_id, marks, absent (bool)
            evidence: 2.4.7 "Absent option"; confidence: high
OtherIncome id, amount, date, note   evidence: v3.0.4; confidence: medium
```
Relationships: Institute 1-n Batch, Batch 1-n Student, Student 1-n Attendance, Student 1-n FeeItem, FeeItem n-n Payment, Batch 1-n Exam, Exam 1-n ExamMark, Institute 1-n Staff.

## Feature matrix

See `features.csv`. Must: 14, should: 13, could: 12, skip: 4.

## Out of scope (cannot or should not be cloned)

- The original's users, their data, and its brand.
- Live online video classes (needs video infrastructure).
- Institute store and fitness tests (separate products).
- Online fee payment to bank accounts (payment and compliance setup; revisit later).
- WhatsApp integration (needs official API access; revisit later).

## Size

Screens 16, flows 6, entities 11. Hard parts: offline-first storage with backup/restore (and sync if you add multi-user), SMS reminders (needs an SMS provider and, in India, sender registration), permission-based staff access. Size: M for the core loop on a phone. Add L-sized work for multi-user cloud sync, which the original has since added.

## Gaps and honesty notes

- Screens are inferred from text, not seen. I could not view screenshots here.
- The listing says "works without internet", yet the privacy label shows email and name linked to identity and newer versions have chat and online payments, so the original is now partly cloud-based. Worth checking in your own account.
- Only 8 ratings exist, so review evidence is thin.
- Check the terms of your Tufee account before using it to build a competitor.
